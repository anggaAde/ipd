 <?php
class User_model extends CI_Model{
    function get_nilai()
    {
        $query=$this->db->query("SELECT * FROM nilai where kelas = '932'");
        return $query->result();
    }
}