 <html>
<head>
    <title><?php echo $judul; ?></title>
</head>
<body>
    <h1>Daftar User</h1>
    <table border="1">
        <thead>
        <tr>
            <th>nrp</th>
            <th>kelas</th>
            <th>dosen</th>
            <th>mata kuliah</th>
            <th>1</th>
            <th>2</th>
            <th>3</th>
            <th>4</th>
            <th>5</th>
            <th>6</th>
            <th>7</th>
            <th>8</th>
            <th>9</th>
            <th>10</th>
            <th>11</th>
            <th>12</th>
            <th>13</th>
            <th>14</th>
            <th>15</th>
            <th>16</th>
            <th>17</th>
            <th>18</th>
            <th>19</th>
            <th>20</th>
            <th>21</th>
            <th>22</th>
            <th>23</th>
            <th>24</th>
            <th>25</th>
            <th>26</th>
            <th>27</th>
            <th>28</th>
            <th>29</th>
            <th>30</th>
            <th>31</th>
            <th>32</th>
            <th>33</th>
            <th>34</th>
            <th>saran</th>
        </tr>
    </thead>
    <tbody>
            <?php
                foreach($daftar_user as $user){
        ?>
                <tr>
            <td><?php echo $user->nrp; ?></td>
            <td><?php echo $user->kelas; ?></td>
            <td><?php echo $user->dos; ?></td>
            <td><?php echo $user->mk; ?></td>
            <td><?php echo $user->n1; ?></td>
            <td><?php echo $user->n2; ?></td>
            <td><?php echo $user->n3; ?></td>
            <td><?php echo $user->n4; ?></td>
            <td><?php echo $user->n5; ?></td>
            <td><?php echo $user->n6; ?></td>
            <td><?php echo $user->n7; ?></td>
            <td><?php echo $user->n8; ?></td>
            <td><?php echo $user->n9; ?></td>
            <td><?php echo $user->n10; ?></td>
            <td><?php echo $user->n11; ?></td>
            <td><?php echo $user->n12; ?></td>
            <td><?php echo $user->n13; ?></td>
            <td><?php echo $user->n14; ?></td>
            <td><?php echo $user->n15; ?></td>
            <td><?php echo $user->n16; ?></td>
            <td><?php echo $user->n17; ?></td>
            <td><?php echo $user->n18; ?></td>
            <td><?php echo $user->n19; ?></td>
            <td><?php echo $user->n20; ?></td>
            <td><?php echo $user->n21; ?></td>
            <td><?php echo $user->n22; ?></td>
            <td><?php echo $user->n23; ?></td>
            <td><?php echo $user->n24; ?></td>
            <td><?php echo $user->n25; ?></td>
            <td><?php echo $user->n26; ?></td>
            <td><?php echo $user->n27; ?></td>
            <td><?php echo $user->n28; ?></td>
            <td><?php echo $user->n29; ?></td>
            <td><?php echo $user->n30; ?></td>
            <td><?php echo $user->n31; ?></td>
            <td><?php echo $user->n32; ?></td>
            <td><?php echo $user->n33; ?></td>
            <td><?php echo $user->n34; ?></td>
            <td><?php echo $user->saran; ?></td>
        </tr>
           <?php } ?>
    </tbody>
    <tfoot>
                <tr>
            <th>nrp</th>
            <th>kelas</th>
            <th>dosen</th>
            <th>mata kuliah</th>
            <th>1</th>
            <th>2</th>
            <th>3</th>
            <th>4</th>
            <th>5</th>
            <th>6</th>
            <th>7</th>
            <th>8</th>
            <th>9</th>
            <th>10</th>
            <th>11</th>
            <th>12</th>
            <th>13</th>
            <th>14</th>
            <th>15</th>
            <th>16</th>
            <th>17</th>
            <th>18</th>
            <th>19</th>
            <th>20</th>
            <th>21</th>
            <th>22</th>
            <th>23</th>
            <th>24</th>
            <th>25</th>
            <th>26</th>
            <th>27</th>
            <th>28</th>
            <th>29</th>
            <th>30</th>
            <th>31</th>
            <th>32</th>
            <th>33</th>
            <th>34</th>
            <th>saran</th>
        </tr>
    </tfoot>
    </table>
</body>
</html>