<html>
<head>
</head>
<body>
<div align='center'>
<br>
<table border='0'>
<tr>
	<td colspan='4'><img src="thanks.jpg" alt=""></td>
</tr>
<tr>
	<td><img src="blank.jpg" width="125" height="110"></td>
	<td> </td>
	<td> </td>
	<td><a href='index.php'><img src="login.jpg" alt="klik untuk login" width="80" height="70"></a></td>
</tr>
</table>
</div>
</body>
</html>